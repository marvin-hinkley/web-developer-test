﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using CustomerServiceTicketing.Data.Entities;
using CustomerServiceTicketing.Models;
using CustomerServiceTicketing.ViewModels;

namespace CustomerServiceTicketing.Data
{
	public class CustomerServiceTicketingMappingProfile : Profile
	{
        public CustomerServiceTicketingMappingProfile()
        {
            CreateMap<TicketViewModel, Ticket>()
                .ReverseMap();

            CreateMap<SubmitTicketModel, Ticket>()
                .ReverseMap();
        }
	}
}
