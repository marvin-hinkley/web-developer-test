﻿using System.Collections.Generic;
using CustomerServiceTicketing.Data.Entities;

namespace CustomerServiceTicketing.Data
{
	public interface ICustomerServiceTicketingRepository
	{
        IEnumerable<Ticket> GetTickets(string customerUsername);
		bool SaveAll();
		void AddEntity(Ticket model);
        CustomerServiceUser GetCustomer(string username);
    }
}