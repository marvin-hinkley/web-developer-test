﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerServiceTicketing.Data.Entities;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using CustomerServiceTicketing.ViewModels;
using AutoMapper;
using Microsoft.AspNetCore.Identity;
using CustomerServiceTicketing.Models;

namespace CustomerServiceTicketing.Data
{
	public class CustomerServiceTicketingRepository : ICustomerServiceTicketingRepository
	{
		private CustomerServiceTicketingContext _context;
		private ILogger<ICustomerServiceTicketingRepository> _logger;
        private IMapper _mapper;
        private UserManager<CustomerServiceUser> _userManager;

        public CustomerServiceTicketingRepository(CustomerServiceTicketingContext context, ILogger<ICustomerServiceTicketingRepository> logger, IMapper mapper, UserManager<CustomerServiceUser> userManager)
		{
			_context = context;
			_logger = logger;
            _mapper = mapper;
            _userManager = userManager;
        }

		public void AddEntity(Ticket model)
		{
			_context.Add(model);
		}

		public bool SaveAll()
		{
			try
			{
				_logger.LogInformation("Calling SaveAll()");
				return _context.SaveChanges() > 0;
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, "Error occured while calling SaveAll()");

				return false;
			}
		}

        IEnumerable<Ticket> ICustomerServiceTicketingRepository.GetTickets(String customerUsername)
        {
            return _context
                .Tickets
                .Where(t => t.Customer.UserName == customerUsername)
                .Include(r => r.Representative)
                .OrderByDescending(t => t.createdOn)
                .ToList();
        }

        public void AddTicket(SubmitTicketModel model)
        {
            var ticket = _mapper.Map<Ticket>(model);
            ticket.Status = Statuses.New;
        }

        public CustomerServiceUser GetCustomer(String username)
        {
            var user = _userManager.FindByEmailAsync(username).Result;
            return user;
        }

    }
}
