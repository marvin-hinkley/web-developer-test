﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerServiceTicketing.Data.Entities;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Newtonsoft.Json;

namespace CustomerServiceTicketing.Data
{
	public class CustomerServiceTicketingSeeder
	{
		private CustomerServiceTicketingContext _context;
		private IHostingEnvironment _hosting;
		private UserManager<CustomerServiceUser> _userManager;

		public CustomerServiceTicketingSeeder(CustomerServiceTicketingContext context, IHostingEnvironment hosting, UserManager<CustomerServiceUser> userManager)
		{
			_context = context;
			_hosting = hosting;
			_userManager = userManager;
		}

		public async Task SeedAsync()
		{
			_context.Database.EnsureCreated();


			CustomerServiceUser user = await _userManager.FindByEmailAsync("alexeiyo@gmail.com") ;
			if (user == null)
			{
				user = new CustomerServiceUser()
				{
					FirstName = "Alexei",
					LastName = "Youditsky",
					Email = "alexeiyo@gmail.com",
					UserName = "alexeiyo@gmail.com"
				};

				var result=await _userManager.CreateAsync(user, "p@ssW0rd?");
				if (result != IdentityResult.Success)
					throw new InvalidOperationException("Failed to create a user in seeder");
                CustomerServiceUser representative = await _userManager.FindByEmailAsync("representative@companymail.com");
                if (representative == null)
                {
                    representative = new CustomerServiceUser()
                    {
                        FirstName = "John",
                        LastName = "Johnson",
                        Email = "representative@companymail.com",
                        UserName = "representative@companymail.com"
                    };

                    result = await _userManager.CreateAsync(representative, "p@ssW0rd?");
                    if (result != IdentityResult.Success)
                        throw new InvalidOperationException("Failed to create a representative user in seeder");
                }

                CustomerServiceUser tecnician = await _userManager.FindByEmailAsync("tecnician@companymail.com");
                if (tecnician == null)
                {
                    tecnician = new CustomerServiceUser()
                    {
                        FirstName = "Jeffrey",
                        LastName = "Jefferson",
                        Email = "tecnician@companymail.com",
                        UserName = "tecnician@companymail.com"
                    };

                    result = await _userManager.CreateAsync(tecnician, "p@ssW0rd?");
                    if (result != IdentityResult.Success)
                        throw new InvalidOperationException("Failed to create a tecnician user in seeder");
                }


                if (!_context.Tickets.Any())
                {
                    _context.Tickets.Add(new Ticket()
                    {
                        Category = Categories.Networking,
                        Customer = user,
                        Description = "Sample Ticket1 Description",
                        ModifiedOn = DateTime.Now.AddDays(-2),
                        Representative = representative,
                        Status = Statuses.Closed,
                        Technician = tecnician,
                        Title = "Sample Ticket1 Title"
                    });
                    _context.Tickets.Add(new Ticket()
                    {
                        Category = Categories.Hardware,
                        Customer = user,
                        Description = "Sample Ticket2 Description",
                        ModifiedOn = DateTime.Now.AddDays(-1),
                        Representative = representative,
                        Status = Statuses.Assigned,
                        Technician = tecnician,
                        Title = "Sample Ticket2 Title"
                    });
                    _context.Tickets.Add(new Ticket()
                    {
                        Category = Categories.Facilities,
                        Customer = user,
                        Description = "Sample Ticket3 Description",
                        ModifiedOn = DateTime.Now,
                        Representative = representative,
                        Status = Statuses.New,
                        Technician = tecnician,
                        Title = "Sample Ticket3 Title"
                    });
                }
                _context.SaveChanges();
            }
        }
	}
}
