﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerServiceTicketing.Data.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CustomerServiceTicketing.Data
{
	public class CustomerServiceTicketingContext : IdentityDbContext<CustomerServiceUser>
	{
		public CustomerServiceTicketingContext(DbContextOptions<CustomerServiceTicketingContext> options) : base(options)
		{

		}
		public DbSet<Ticket> Tickets { get; set; }
	}
}
