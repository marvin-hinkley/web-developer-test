﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace CustomerServiceTicketing.Data.Entities
{
    public class CustomerServiceUser:IdentityUser
    {
		public String FirstName { get; set; }
		public String LastName { get; set; }

	}
}
