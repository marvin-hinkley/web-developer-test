﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerServiceTicketing.Data.Entities
{
    public enum Statuses
    {
        New, Assigned,  Closed
    };

    public enum Categories
    {
        Networking, Software, Hardware,  Facilities
    }

    public class Ticket
    {
        public int Id { get; set; }
        [Required]
        public DateTime createdOn { get; set; } = DateTime.Now;
        [Required]
        public DateTime ModifiedOn { get; set; }
        public string Title { get; set; }
        [Required]
        public CustomerServiceUser Customer { get; set; }
        public String Description { get; set; }
        public CustomerServiceUser Representative { get; set; }
        public CustomerServiceUser Technician { get; set; }
        [Required]
        public Statuses Status { get; set; }
        public Categories Category { get; set; }

    }
}

