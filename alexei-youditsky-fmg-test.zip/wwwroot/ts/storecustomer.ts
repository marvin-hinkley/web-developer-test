﻿//export 
class StoreCustomer {
    constructor(private firstName:string,private lastName:string) {
    }
    public visits: number = 0;
    private _name: string="";

    public showName() {
        alert(this.firstName + " " + this.lastName);
    }

    set name(val) {
        this._name = val; 

    }

    get name(): string {
        return this._name;
    }
}

