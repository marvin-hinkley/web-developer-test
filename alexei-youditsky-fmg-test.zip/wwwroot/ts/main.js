//import { StoreCustomer } from "./storecustomer";
var cust = new StoreCustomer("Alexei", "Youditsky");
cust.visits = 10;
//cust.showName(" ");
//# sourceMappingURL=main.js.map