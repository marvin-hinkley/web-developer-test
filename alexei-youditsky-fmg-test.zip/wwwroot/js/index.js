﻿$(document).ready(function () {
    console.log("Starting...");
    var $theform = $("#theForm");
    //theform.hide();
    var $buybutton = $("#buyButton");
    $buybutton.on("click", function () {
        console.log("clicked " + this.id);
    });

    var $productInfo=$(".product-props li");
    $productInfo.on("click", function () {
        console.log("clicked " + $(this).text());
    });

    var $loginToggle = $("#loginToggle");
    var popupForm = $(".popup-form");

    $loginToggle.on("click", function () {
        popupForm.fadeToggle(500);
    });
});
