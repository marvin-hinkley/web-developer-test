﻿using CustomerServiceTicketing.Data.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerServiceTicketing.ViewModels
{
	public class TicketViewModel
	{
		public Int32 Id { get; set; }
        public DateTime ModifiedOn { get; set; }
        public string Title { get; set; }
        public String Description { get; set; }
        public CustomerServiceUser Representative { get; set; }
        public Statuses Status { get; set; }
		public DateTime createdOn { get; set; }
    }
}
