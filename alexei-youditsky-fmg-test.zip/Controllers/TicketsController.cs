﻿using AutoMapper;
using CustomerServiceTicketing.Data;
using CustomerServiceTicketing.Data.Entities;
using CustomerServiceTicketing.Models;
using CustomerServiceTicketing.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerServiceTicketing.Controllers
{
    [Authorize]
    public class TicketsController:Controller
    {
        private ICustomerServiceTicketingRepository _repository;
        private IMapper _mapper;

        public TicketsController(ICustomerServiceTicketingRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult Get()
        {
            if (User.Identity.IsAuthenticated)
                return View(_mapper.Map<IEnumerable<TicketViewModel>>(_repository.GetTickets(User.Identity.Name)));
            else
                return RedirectToAction("Login", "Account");
        }
        
        [HttpGet("submit")]
        public IActionResult Post()
        {
            return View();
        }

        [HttpPost("submit")]
        public IActionResult Post(SubmitTicketModel model)
        {
            if (ModelState.IsValid)
            {
                model.Customer = _repository.GetCustomer(User.Identity.Name);
                _repository.AddEntity(_mapper.Map<Ticket>(model));
                _repository.SaveAll();
                ModelState.Clear();
                ViewBag.UserMessage = "Submitted.";
            }
            else
            {
                
            }
            return View();
        }
    }
}
