﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerServiceTicketing.Data;
using CustomerServiceTicketing.Data.Entities;
using Microsoft.AspNetCore.Mvc;

namespace CustomerServiceTicketing.Controllers
{
	public class AppController : Controller
	{
		private ICustomerServiceTicketingRepository _repository;
		
		public AppController(ICustomerServiceTicketingRepository repository)
		{
			_repository = repository;
		}
		public IActionResult Index()
		{
			//throw new InvalidOperationException("Bad things happened.");
			return View();
		}

		[HttpGet("about")]
		public IActionResult About()
		{
			ViewBag.Title = "About Us";
			return View();
		}
	}
}
