﻿using CustomerServiceTicketing.Data.Entities;
using System;
using System.ComponentModel.DataAnnotations;

namespace CustomerServiceTicketing.Models
{
    public class SubmitTicketModel
    {
        [Required]
        [StringLength(200, MinimumLength =10)]
        public string Title { get; set; }
        [Required]
        [StringLength(2000, MinimumLength = 10)]
        public String Description { get; set; }

        public CustomerServiceUser Customer { get; set; }
    }
}